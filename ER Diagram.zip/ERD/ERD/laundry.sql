-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 11, 2022 at 05:55 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laundry`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_member`
--

CREATE TABLE `tb_member` (
  `id_member` int(11) NOT NULL,
  `nama_member` varchar(100) NOT NULL,
  `alamat` text NOT NULL,
  `jenis_kelamin` enum('L','P') NOT NULL,
  `telp` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_member`
--

INSERT INTO `tb_member` (`id_member`, `nama_member`, `alamat`, `jenis_kelamin`, `telp`) VALUES
(1, 'Paul Rudd', ' Banjaran', 'L', '087879726775'),
(2, 'Jordan belfort', '  Manggahang', 'L', '089676867899'),
(3, 'Zendaya', ' Ciparay', 'P', '087876765655'),
(4, 'Valeria schwertz', ' Balendah', 'P', '087976765231'),
(6, 'Warren buffet ', '  Jelekong', 'L', '089786895952'),
(9, 'Michael B. Jordan', '  Baranangsiang', 'L', '089765432104'),
(10, 'Christopher Nolan', 'Bumi Siliwangi', 'L', '087654324554'),
(11, 'Steven Grant', ' Cijagra', 'L', '085645344251'),
(12, 'Layla El Noor', ' Cikutra', 'P', '087654343532'),
(13, 'Fildza Rohma ', ' Manggahang', 'P', '089765464544'),
(14, 'Wicaksono Wibowo', ' Babakan Siliwangi', 'L', '087976789876'),
(15, 'Scarlett Johansen ', ' Ciparay', 'P', '086454343220'),
(16, 'Morgan Freeman', 'Cikoneng ', 'L', '089874543342'),
(17, 'Oscar Isaac', 'Bumi Siliwangi ', 'L', '088787923214'),
(18, 'Stanley Kubrik', 'Baranangsiang ', 'L', '087879766765');

-- --------------------------------------------------------

--
-- Table structure for table `tb_outlet`
--

CREATE TABLE `tb_outlet` (
  `id_outlet` int(11) NOT NULL,
  `nama_outlet` varchar(100) NOT NULL,
  `alamat` text NOT NULL,
  `telp` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_outlet`
--

INSERT INTO `tb_outlet` (`id_outlet`, `nama_outlet`, `alamat`, `telp`) VALUES
(1, 'Laundry Outlet Baleendah', 'Jl. Siliwangi KM 15 Baleendah', '087879729335');

-- --------------------------------------------------------

--
-- Table structure for table `tb_paket`
--

CREATE TABLE `tb_paket` (
  `id_paket` int(11) NOT NULL,
  `id_outlet` int(11) NOT NULL,
  `jenis` enum('kiloan','satuan') NOT NULL,
  `nama_paket` varchar(100) NOT NULL,
  `harga` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_paket`
--

INSERT INTO `tb_paket` (`id_paket`, `id_outlet`, `jenis`, `nama_paket`, `harga`) VALUES
(1, 1, 'kiloan', 'Cuci kilat', 12000),
(2, 1, 'satuan', 'Cuci Hemat', 9000);

-- --------------------------------------------------------

--
-- Table structure for table `tb_transaksi`
--

CREATE TABLE `tb_transaksi` (
  `id_transaksi` int(11) NOT NULL,
  `id_outlet` int(11) NOT NULL,
  `kode_invoice` varchar(100) NOT NULL,
  `id_member` int(11) NOT NULL,
  `tgl` date NOT NULL,
  `selesai` date NOT NULL,
  `id_paket` int(11) NOT NULL,
  `biaya_tambahan` int(11) NOT NULL,
  `diskon` int(11) NOT NULL,
  `total` double NOT NULL,
  `status` enum('baru','proses','selesai','diambil') NOT NULL,
  `id_user` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_transaksi`
--

INSERT INTO `tb_transaksi` (`id_transaksi`, `id_outlet`, `kode_invoice`, `id_member`, `tgl`, `selesai`, `id_paket`, `biaya_tambahan`, `diskon`, `total`, `status`, `id_user`) VALUES
(3, 1, 'INVC-2453435897', 3, '2022-03-31', '2022-04-01', 1, 5000, 10, 15300, 'diambil', 3),
(4, 1, 'INVC-2348987879', 2, '2022-03-31', '2022-04-01', 2, 5000, 10, 12600, 'selesai', 3),
(5, 1, 'INVC-8461271721', 4, '2022-04-01', '2022-04-01', 1, 5000, 10, 15300, 'selesai', 3),
(6, 1, 'INVC-2681467289', 2, '2022-04-01', '2022-04-01', 2, 5000, 10, 12600, 'selesai', 3),
(7, 1, 'INVC-6578934428', 1, '2022-04-03', '2022-04-04', 1, 5000, 10, 15300, 'selesai', 3),
(8, 1, 'INVC-5467438322', 9, '2022-04-03', '2022-04-04', 1, 5000, 10, 15300, 'selesai', 3),
(9, 1, 'INVC-4563435323', 4, '2022-04-03', '2022-04-04', 1, 5000, 10, 15300, 'diambil', 3),
(10, 1, 'INVC-8767906721', 3, '2022-04-04', '2022-04-05', 1, 5000, 10, 15300, 'proses', 3),
(11, 1, 'INVC-8752517292', 4, '2022-04-04', '2022-04-05', 2, 5000, 10, 12600, 'proses', 3),
(12, 1, 'INVC-8676453736', 3, '2022-04-08', '2022-04-09', 1, 5000, 10, 15300, 'proses', 3),
(14, 1, 'INVC-8548987879', 10, '2022-04-09', '2022-04-10', 1, 5000, 10, 15300, 'proses', 3),
(15, 1, 'INVC-6545567994', 13, '2022-04-11', '2022-04-12', 2, 5000, 10, 12600, 'proses', 3),
(16, 1, 'INVC-2254647665', 18, '2022-04-11', '2022-04-12', 2, 0, 0, 9000, 'proses', 3),
(17, 1, 'INVC-8799878666', 17, '2022-04-11', '2022-04-12', 1, 0, 0, 12000, 'baru', 3),
(18, 1, 'INVC-5543347789', 11, '2022-04-11', '2022-04-12', 1, 0, 0, 12000, 'baru', 3),
(19, 1, 'INVC-8323244232', 16, '2022-04-11', '2022-04-12', 1, 0, 0, 12000, 'baru', 3);

-- --------------------------------------------------------

--
-- Table structure for table `tb_user`
--

CREATE TABLE `tb_user` (
  `id_user` int(11) NOT NULL,
  `nama_user` varchar(100) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` text NOT NULL,
  `id_outlet` int(11) NOT NULL,
  `role` enum('admin','kasir','owner') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_user`
--

INSERT INTO `tb_user` (`id_user`, `nama_user`, `username`, `password`, `id_outlet`, `role`) VALUES
(3, 'Muhamad Ridwan', 'admin01', '202cb962ac59075b964b07152d234b70', 1, 'admin'),
(4, 'Ryo Ikhsan', 'kasir01', '202cb962ac59075b964b07152d234b70', 1, 'kasir'),
(5, 'Dadi Bilawa', 'owner01', '250cf8b51c773f3f8dc8b4be867a9a02', 1, 'owner');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_member`
--
ALTER TABLE `tb_member`
  ADD PRIMARY KEY (`id_member`);

--
-- Indexes for table `tb_outlet`
--
ALTER TABLE `tb_outlet`
  ADD PRIMARY KEY (`id_outlet`);

--
-- Indexes for table `tb_paket`
--
ALTER TABLE `tb_paket`
  ADD PRIMARY KEY (`id_paket`),
  ADD KEY `relasi outlet dan paket` (`id_outlet`);

--
-- Indexes for table `tb_transaksi`
--
ALTER TABLE `tb_transaksi`
  ADD PRIMARY KEY (`id_transaksi`),
  ADD KEY `relasi outlet dan transaksi` (`id_outlet`),
  ADD KEY `relasi member dan transaksi` (`id_member`),
  ADD KEY `relasi paket dan transaksi` (`id_paket`),
  ADD KEY `relasi user dan transaksi` (`id_user`);

--
-- Indexes for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`id_user`),
  ADD KEY `relasi outlet dan user` (`id_outlet`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_member`
--
ALTER TABLE `tb_member`
  MODIFY `id_member` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `tb_outlet`
--
ALTER TABLE `tb_outlet`
  MODIFY `id_outlet` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tb_paket`
--
ALTER TABLE `tb_paket`
  MODIFY `id_paket` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tb_transaksi`
--
ALTER TABLE `tb_transaksi`
  MODIFY `id_transaksi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `tb_user`
--
ALTER TABLE `tb_user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tb_paket`
--
ALTER TABLE `tb_paket`
  ADD CONSTRAINT `relasi outlet dan paket` FOREIGN KEY (`id_outlet`) REFERENCES `tb_outlet` (`id_outlet`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tb_transaksi`
--
ALTER TABLE `tb_transaksi`
  ADD CONSTRAINT `relasi member dan transaksi` FOREIGN KEY (`id_member`) REFERENCES `tb_member` (`id_member`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `relasi outlet dan transaksi` FOREIGN KEY (`id_outlet`) REFERENCES `tb_outlet` (`id_outlet`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `relasi paket dan transaksi` FOREIGN KEY (`id_paket`) REFERENCES `tb_paket` (`id_paket`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `relasi user dan transaksi` FOREIGN KEY (`id_user`) REFERENCES `tb_user` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD CONSTRAINT `relasi outlet dan user` FOREIGN KEY (`id_outlet`) REFERENCES `tb_outlet` (`id_outlet`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
